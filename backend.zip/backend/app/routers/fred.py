from fastapi import APIRouter
from services.fred_service import execute

router = APIRouter()


@router.post("/chat")
def chat(payload: dict):

    command = payload.get("message", "")

    return execute(command)
