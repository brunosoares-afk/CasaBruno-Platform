from fastapi import APIRouter
from services.homeassistant_service import (
    get_homeassistant_status,
    get_states,
    get_config,
)

router = APIRouter()


@router.get("/status")
def status():
    return get_homeassistant_status()


@router.get("/states")
def states():
    return get_states()


@router.get("/config")
def config():
    return get_config()
