import requests

HA_URL = "http://192.168.2.80:8123"

HA_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiI5MWI2ZWNhOGMyMWQ0MzI0YWYzMTBmZTRiNTU3MmZiNyIsImlhdCI6MTc4MjIyODMyMiwiZXhwIjoyMDk3NTg4MzIyfQ.X9euFARhgR5ypgDw1f6Mwwy7gE_DIJ5IKtEHy1jC7mc"

headers = {
    "Authorization": f"Bearer {HA_TOKEN}",
    "Content-Type": "application/json",
}


def get_homeassistant_status():

    try:

        response = requests.get(
            f"{HA_URL}/api/",
            headers=headers,
            timeout=10,
        )

        return {
            "online": response.status_code == 200,
            "status": response.json()
        }

    except Exception as e:

        return {
            "online": False,
            "error": str(e)
        }


def get_states():

    response = requests.get(
        f"{HA_URL}/api/states",
        headers=headers,
        timeout=20,
    )

    return response.json()


def get_config():

    response = requests.get(
        f"{HA_URL}/api/config",
        headers=headers,
        timeout=20,
    )

    return response.json()


def call_service(domain, service, entity_id):

    payload = {
        "entity_id": entity_id
    }

    try:

        response = requests.post(
            f"{HA_URL}/api/services/{domain}/{service}",
            headers=headers,
            json=payload,
            timeout=20,
        )

        try:
            result = response.json()
        except Exception:
            result = response.text

        return {
            "success": response.status_code == 200,
            "domain": domain,
            "service": service,
            "entity_id": entity_id,
            "result": result
        }

    except Exception as e:

        return {
            "success": False,
            "domain": domain,
            "service": service,
            "entity_id": entity_id,
            "error": str(e)
        }
