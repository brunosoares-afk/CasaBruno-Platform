from services.homeassistant_service import (
    call_service,
    get_states,
)


class AutomationEngine:

    def execute(self, intent):

        if intent is None:
            return {
                "success": False,
                "message": "Não consegui entender o comando."
            }

        t = intent.get("type")

        if t == "device_action":
            return self._device_action(intent)

        if t == "device_status":
            return self._device_status(intent)

        return {
            "success": False,
            "message": "Intent desconhecida."
        }

    def _device_action(self, intent):

        entity_id = intent["entity_id"]

        domain = entity_id.split(".")[0]

        action = intent["action"]

        return call_service(
            domain,
            action,
            entity_id
        )

    def _device_status(self, intent):

        entity_id = intent["entity_id"]

        states = get_states()

        for entity in states:

            if entity["entity_id"] == entity_id:

                return {
                    "success": True,
                    "entity_id": entity_id,
                    "state": entity["state"],
                    "attributes": entity.get("attributes", {})
                }

        return {
            "success": False,
            "message": "Dispositivo não encontrado."
        }


automation_engine = AutomationEngine()


