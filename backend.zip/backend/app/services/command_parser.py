import re

ACTION_ON = [
    "ligar",
    "acender",
    "ativar",
    "abrir",
]

ACTION_OFF = [
    "desligar",
    "apagar",
    "fechar",
]

STATUS = [
    "estado",
    "status",
    "como esta",
    "como está",
]

INFO = [
    "listar",
    "mostrar",
]


class ParsedCommand:

    def __init__(self):

        self.intent = None
        self.device = None
        self.raw = ""


def normalize(text):

    return (
        text.lower()
        .replace("á","a")
        .replace("à","a")
        .replace("â","a")
        .replace("ã","a")
        .replace("é","e")
        .replace("ê","e")
        .replace("í","i")
        .replace("ó","o")
        .replace("ô","o")
        .replace("õ","o")
        .replace("ú","u")
        .replace("ç","c")
    )


def parse(command):

    result = ParsedCommand()

    command = normalize(command)

    result.raw = command

    for word in ACTION_ON:

        if command.startswith(word):

            result.intent = "turn_on"

            result.device = command.replace(word,"").strip()

            return result

    for word in ACTION_OFF:

        if command.startswith(word):

            result.intent = "turn_off"

            result.device = command.replace(word,"").strip()

            return result

    for word in STATUS:

        if word in command:

            result.intent = "status"

            result.device = command.replace(word,"").strip()

            return result

    if "dispositivos" in command:

        result.intent = "devices"

        return result

    if "switches" in command:

        result.intent = "switches"

        return result

    if "sensores" in command:

        result.intent = "sensors"

        return result

    result.intent = "unknown"

    return result
