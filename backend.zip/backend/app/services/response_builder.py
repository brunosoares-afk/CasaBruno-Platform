class ResponseBuilder:

    def build(self, result):

        if result is None:

            return {
                "success": False,
                "message": "Sem resposta."
            }

        if not result.get("success", False):

            return result

        if "state" in result:

            return {
                "success": True,
                "message": f"{result['entity_id']} está {result['state']}"
            }

        if "result" in result:

            return {
                "success": True,
                "message": "Comando executado com sucesso.",
                "details": result["result"]
            }

        return result


response_builder = ResponseBuilder()
