from services.device_registry import registry


class IntentEngine:

    def parse(self, command: str):

        cmd = command.lower()

        if "ligar" in cmd:
            return self._device_intent(cmd, "turn_on")

        if "desligar" in cmd:
            return self._device_intent(cmd, "turn_off")

        if "status" in cmd:
            return self._device_status(cmd)

        return None

    def _device_intent(self, cmd, action):

        devices = registry.search(cmd)

        if not devices:
            return None

        return {
            "type": "device_action",
            "action": action,
            "entity_id": devices[0]["entity_id"]
        }

    def _device_status(self, cmd):

        devices = registry.search(cmd)

        if not devices:
            return None

        return {
            "type": "device_status",
            "entity_id": devices[0]["entity_id"]
        }


intent_engine = IntentEngine()
