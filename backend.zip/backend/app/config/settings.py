from dotenv import load_dotenv
import os

load_dotenv()


class Settings:

    APP_NAME = os.getenv(
        "APP_NAME",
        "CasaBruno Platform"
    )

    APP_VERSION = os.getenv(
        "APP_VERSION",
        "0.1.0"
    )

    HA_URL = os.getenv(
        "HA_URL"
    )

    HA_TOKEN = os.getenv(
        "HA_TOKEN"
    )

    DOCKER_SOCKET = os.getenv(
        "DOCKER_SOCKET",
        "/var/run/docker.sock"
    )

    REFRESH_SECONDS = int(
        os.getenv(
            "REFRESH_SECONDS",
            "5"
        )
    )


settings = Settings()
