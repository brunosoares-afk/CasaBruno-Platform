from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routers import system
from routers import docker
from routers import homeassistant
from routers import dashboard
from routers import fred

app = FastAPI(
    title="T&B Residencial OS"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(
    system.router,
    prefix="/api/system",
    tags=["System"]
)

app.include_router(
    docker.router,
    prefix="/api/docker",
    tags=["Docker"]
)

app.include_router(
    homeassistant.router,
    prefix="/api/homeassistant",
    tags=["Home Assistant"]
)

app.include_router(
    dashboard.router,
    prefix="/api",
    tags=["Dashboard"]
)

app.include_router(
    fred.router,
    prefix="/api/fred",
    tags=["Fred"]
)


@app.get("/")
def root():

    return {
        "project": "T&B Residencial OS",
        "assistant": "Fred",
        "status": "online"
    }
